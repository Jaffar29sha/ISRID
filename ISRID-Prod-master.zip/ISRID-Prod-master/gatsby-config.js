module.exports = {
  siteMetadata: {
    title: 'IOWA STATE REGISTRY OF INTERPRETERS FOR THE DEAF',
    subTitle: 'calendar',
    formLink: '',
    author: 'anna-morawska',
  },
  plugins: [
    `gatsby-plugin-react-helmet`,
    {
      resolve: `gatsby-source-filesystem`,
      options: {
        name: `images`,
        path: `${__dirname}/src/images`,
      },
    },
    {
      resolve: 'gatsby-source-strapi',
      options: {
        secure: false,
        //apiURL: 'http://54.156.73.182:1337',
        // apiURL: 'http://localhost:1337/',
        // apiURL: 'https://isridstrapi.com',
        apiURL: 'https://cp.iowastaterid.org', 
        //apiURL: 'https://isrid.testsitemegarcus.com',
        contentTypes: [
          'Logins',
          'Navbars',
          'Subnavbars',
          'Homes',
          'Members',
          'Footers',
          'Events',
          'Abouts',
          'Bylaws',
          'Contacts',
          'Sponsors',
          'Jobs',
          'Employments',
          'Calendarevents',
          'conf-registration-forms',
          'Newsletteruploads',
          'Minuteuploads',
          'Minutes',
          'JOIN-RENEW-PAGES',
          'MEMBERSHIP-APPLICATION',
          'ONLINE-PAYMENT-PAGES',
          'MEMORIAM-COLLECION-TYPES',
          'INTERPRETER-SEARCHES', 
          'MANAGE-ACCOUNTS',
          'NOMINATES',
          'VOLUNTEERS',
          'PPM-Pages',
          'CMPS',
          'cmpsponsers',
//           'topbanners',
        
  
        ],
        queryLimit: 1000,
      },
    },
    `gatsby-transformer-sharp`,
    `gatsby-plugin-sharp`,
    `gatsby-plugin-svgr`,
    {
      resolve: `gatsby-plugin-manifest`,
      options: {
        name: `gatsby-material-design-for-bootstrap`,
        short_name: `gatsby`,
        start_url: `/`,
        background_color: `#4B5EB8`,
        theme_color: `#68008C`,
        display: `standalone`,
        icon: `${__dirname}/src/images/Logo_Image.png`, // This path is relative to the root of the site.
      },
    },
    {
      resolve: 'gatsby-plugin-contentful-optional-fields',
      options: {
        optionalFields: {},
      },
    },
    {
      resolve: `gatsby-plugin-breadcrumb`,
      options: {
        // useAutoGen: required 'true' to use autogen
        //useAutoGen: true,
        // autoGenHomeLabel: optional 'Home' is default
        //autoGenHomeLabel: `Root`,
        // defaultCrumb: optional To create a default crumb
        // see Click Tracking default crumb example below
        defaultCrumb: {
          location: {
            pathname: '/',
          },
          crumbLabel: 'Home ',
          crumbSeparator: '/',
        },
        // usePathPrefix: optional, if you are using pathPrefix above
        //usePathPrefix: '/blog',
      },
    },
    // this (optional) plugin enables Progressive Web App + Offline functionality
    // To learn more, visit: https://gatsby.app/offline
    'gatsby-plugin-offline',
  ],
}
