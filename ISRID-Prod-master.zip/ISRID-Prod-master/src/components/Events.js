import React from 'react'
import './board.css'
import Event from './Event'
export const Events = ({
  events,
  title,
  bg_color,
  showLink,
  loginData,
  loginRequest,
}) => {
  //console.log('event', events)
  return (
    <div className="box center">
      <div className="box center">
        <div className="container">
          <div className="row">
            {events.map((event, index) => {
              return <Event key={index} {...event} />
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Events
