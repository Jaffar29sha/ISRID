import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import Stepper from '@material-ui/core/Stepper'
import Step from '@material-ui/core/Step'
import StepLabel from '@material-ui/core/StepLabel'
import StepContent from '@material-ui/core/StepContent'
import Typography from '@material-ui/core/Typography'

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
  },
}))

const StepperComp = ({ stepData }) => {
  const classes = useStyles()

  return (
    <div className={classes.root}>
      <label> {stepData.step} </label>
      <Stepper activeStep={-1} orientation="vertical">
        
        {stepData.data &&
          stepData.data.map((label, index) => {
            return (
              <Step active={true}>
                <StepLabel> {label.title} </StepLabel>
                <StepContent>
                  <Typography> {label.content} </Typography>
                </StepContent>
              </Step>
            )
          })}
      </Stepper>
    </div>
  )
}

export default StepperComp
