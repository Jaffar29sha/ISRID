import React from 'react'
import { useStaticQuery, graphql } from 'gatsby'
import { Link } from 'gatsby'
import '../board.css'
import { BASEURL } from '../../utils/constants'

export const query = graphql`
  {
    allStrapiMinutes {
      nodes {
        minute_font_color {
          color
        }
        minute_font_family {
          family
        }
        minute_font_size {
          size
        }
        minute_font_weight {
          weight
        }
        minute_title
        minute_slug
        minutes_file {
          newsletter_heading
          titile_align
          bg_color {
            color
          }
          font_color {
            color
          }
          font_family {
            family
          }
          font_size {
            size
          }
          font_weight {
            weight
          }
          newsletter_data {
            file_name
            file_order
            file_type
            file {
              publicURL
              name
            }
          }
        }
      }
    }
  }
`
const MinutesEvents = () => {
  const data = useStaticQuery(query)
  const {
    allStrapiMinutes: { nodes: files },
  } = data
  const baseURL = BASEURL
  const newsletterData = files[0]
  //console.log(newsletterData)
  return (
    <div className="box center card minutes_card">
      <h2
        className="heading"
        style={{
          color: newsletterData.minute_font_color.color,
          fontSize: newsletterData.minute_font_size.size,
          fontWeight: newsletterData.minute_font_weight.weight,
          fontFamily: newsletterData.minute_font_family.family,
        }}
      >
        {newsletterData.minute_title}
      </h2>
      <div className="box center">
        <div className="container">
          <div className="row">
            {newsletterData.minutes_file.map((news, index) => (
              <div className="col-md-6" key={index}>
                <div
                  className="team-player"
                  style={{
                    height: '325px',
                    backgroundColor: news.bg_color.color,
                  }}
                >
                  <h3
                    style={{
                      color: newsletterData.minute_font_color.color,
                      fontSize: newsletterData.minute_font_size.size,
                      textAlign: news.titile_align,
                      fontFamily: news.font_family.family,
                    }}
                  >
                    {news.newsletter_heading}
                  </h3>

                  <ul className="ListStyle">
                    {news.newsletter_data.map((desc, index) => (
                      <Link
                        to={desc.file ? baseURL + desc.file.publicURL : ''}
                        key={index}
                        target="_blank"
                      >
                        <li
                          style={{
                            color: news.font_color.color,
                            fontSize: news.font_size.size,
                            fontWeight: news.font_weight.weight,
                            fontFamily: news.font_family.family,
                          }}
                          className="liItem"
                          key={index}
                        >
                          <p> {desc.file_name}</p>
                        </li>
                      </Link>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default MinutesEvents
