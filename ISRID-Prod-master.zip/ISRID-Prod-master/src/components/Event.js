import React, { useState } from 'react'
import './board.css';
import { Link } from 'gatsby'

const Event = ({
  id,
  description,
  image,
  image_details,
  slug,
  font_family,
  font_color,
  font_size,
  font_weight,
  title,
  title_align,
  content_align,
  bg_color,
  event_classname,
}) => {
  return (
    <>
      <div className={event_classname ? event_classname : 'col-md-6'}>
        <div className="team-player frontpagecard" style={{ backgroundColor: bg_color.color }}>
          <h3 style={{ textAlign: title_align, fontFamily: font_family.family }}>
            {title}
          </h3>
          {image_details && (<div><img {...image_details} style={{ ...image_details, height: "260px", width: "235px", border: "2px solid black" }} /><br /><br /></div>)}

          <ul className="ListStyle">
            {description.map((desc, index) => (
              <Link to={`/board/${slug}?id=${desc.id}`} key={index}>
                <li
                  className="liItem"
                  style={{
                    listStyle: content_align,
                    color: font_color.color,
                    fontSize: font_size.size,
                    fontWeight: font_weight.weight,
                    fontFamily: font_family.family,
                  }}
                  key={index}
                >
                  <p
                    style={{
                      color: font_color.color,
                      fontSize: font_size.size,
                      fontWeight: font_weight.weight,
                      fontFamily: font_family.family,
                      cursor: 'pointer',
                    }}
                  >
                    {desc.description}
                  </p>
                </li>
              </Link>
            ))}
          </ul>
        </div>
      </div>
    </>
  )
}

export default Event
