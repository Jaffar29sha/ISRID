// import React from "react";
// import { AXIOSLINK } from "../../utils/constants";
// const axios = require('axios')
// import './interpreterSearch.css'
// import { isEmpty } from "lodash";
// import MDEditor from '@uiw/react-md-editor';
// import not from '../../images/notfound.png'


 
// export default class StateCitySearch extends React.Component{
//   state ={
//       codes : [],
      
//   };
//   componentDidMount(){
//       const StateCitySearchData = typeof window !== 'undefined' ? JSON.parse(sessionStorage.getItem("StateCitySearchData")) : null;
//       typeof window !== 'undefined' ?sessionStorage.clear() : null
    
//     //console.log(StateCitySearchData)

//      if(isEmpty(StateCitySearchData.city)==false && isEmpty(StateCitySearchData.state)==false){
//         axios
//         .get(AXIOSLINK + 'users', {
//           params: { City: StateCitySearchData.city,State : StateCitySearchData.state , Opt: true},
//         })
//         .then(res => {
//           //console.log(res)
//           this.setState({ codes: res.data })
//         })
//       }

//      else if(isEmpty(StateCitySearchData.state)== false ){
//         axios
//         .get(AXIOSLINK + 'users', {
//           params: { State : StateCitySearchData.state, Opt: true},
//         })
//         .then(res => {
//           //console.log(res)
//           this.setState({ codes: res.data })
//         })
//       }
//       else if(isEmpty(StateCitySearchData.city)== false ){
//         axios
//         .get(AXIOSLINK + 'users', {
//           params: { City: StateCitySearchData.city, Opt: true },
//         })
//         .then(res => {
//           //console.log(res)
//           this.setState({ codes: res.data })
//         })
//       }

    
//   }
  
  
//   render(){
        
//         if(this.state.codes.length == 0){
//           //console.log("true")
//           return (
//             <div class="center">
//             <img src={not}  style={{ width: '25%', height: '25%' }}/>
//             <br/>
//             <h1><b>No Result Found</b></h1>
//             <br />
//             <p style={{fontSize:"20px"}}><b>We're sorry. We were not able to find a match. </b></p>
//             <p style={{fontSize:"20px"}}><b>Double check your search for any typos or spelling errors.</b></p>
//             <br/>
//             <button type="submit" class="btn btn-success notfoundbtn" 
//                     style={{backgroundColor:"rgb(0, 128, 0)",
//                     borderRadius:"7px",
//                     fontSize:"16px",
//                     width:"25%"}}>SEARCH  AGAIN</button>
//             <br />
//           </div>
//           )
//         }
//       return (
        
//           <div className="container">
//             <div class="row">
//               {this.state.codes.map(code => (
//                 <div class="single_box">
//                   <div style={{ padding: '20px' }}>
//                     <p className="uppercase center" key={code.id}><b>{code.FirstName + " " +code.LastName}</b></p>
//                     {/* <p key={code.id}>Email :{code.email}</p>
//                     <p key={code.id}>Zipcode :{code.Zipcode}</p>
//                     <p key={code.id}>City :{code.City}</p>
//                     <p key={code.id}>State :{code.State}</p>
//                     <p key={code.id}>PhoneNumber :{code.UserPhoneNumber}</p> */}
//                     <p  key={code.id}>
//                         <MDEditor.Markdown source={code.InterpreterSearchData} /></p>
//                     <p key={code.id}>License Type:{" "+code.LicenseType}</p>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>

//       )
//   }
// }