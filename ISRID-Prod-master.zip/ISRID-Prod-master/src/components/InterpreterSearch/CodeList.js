// import React from "react";
// import { AXIOSLINK } from "../../utils/constants";
// const axios = require('axios')
// import './interpreterSearch.css'
// import { isEmpty } from "lodash";
// import MDEditor from '@uiw/react-md-editor';
// import not from '../../images/notfound.png'


 
// export default class CodeSearch extends React.Component{
//   state ={
//       codes : [],
      
//   };
//   componentDidMount(){
//       const CodeSearchData = typeof window !== 'undefined' ? sessionStorage.getItem("CodeSearchData"): null;
//       typeof window !== 'undefined' ?sessionStorage.clear() : null
    
//     //console.log(CodeSearchData)

//      if(isEmpty(CodeSearchData)==false){
//       axios
//         .get(AXIOSLINK + 'users', {
//           params: { Zipcode : CodeSearchData, Opt: true},
//         })
//         .then(res => {
//           //console.log(res)
//           this.setState({ codes: res.data })
//         })
//     }
    
//   }
  
  
//   render(){
        
//       return (
        
//           <div className="container">
//             <div class="row">
//               {this.state.codes.map(code => (
//                 <div class="single_box">
//                   <div style={{ padding: '20px' }}>
//                     <p className="uppercase" key={code.id}><b>{code.FirstName + " " +code.LastName}</b></p>
//                     {/* <p key={code.id}>Email :{code.email}</p>
//                     <p key={code.id}>Zipcode :{code.Zipcode}</p>
//                     <p key={code.id}>City :{code.City}</p>
//                     <p key={code.id}>State :{code.State}</p>
//                     <p key={code.id}>PhoneNumber :{code.UserPhoneNumber}</p> */}
//                     <p className="uppercase" key={code.id}>
//                         <MDEditor.Markdown source={code.InterpreterSearchData} /></p>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>

//       )
//   }
// }