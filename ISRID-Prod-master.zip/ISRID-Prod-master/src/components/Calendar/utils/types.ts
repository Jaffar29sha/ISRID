type EventInfo = {
    id: string;
    cal_event_name: string;
    cal_event_date: Date;
    cal_event_link: string;
    cal_event_place: string;
  };
  
 type ModalData = {
    date: Date;
    events: EventInfo[];
  };
  
  type MonthInfo = {
    startDate: Date;
    events: EventInfo[];
  };
  