import { parse,parseISO } from 'date-fns';

const DATE_FORMAT = 'MM/dd/yyyy';

export const parseEventDate = (date: string) => parse(date, DATE_FORMAT, 0);

// export const parseEventDateTest = (date) => parseISO(date,'MM/dd/yyyy');
