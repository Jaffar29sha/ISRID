import { isEmpty } from "lodash"
import React, { useState } from "react"
import '../../assets/workshop.css'
import Swal from 'sweetalert2'
var validator = require('validator');

const Workshop = () =>{

    const initialFormData = Object.freeze({
        FirstName: '',
        LastName: '',
        emailAddress: '',  
        mailedAddress:'',
        lunch:'',
        // attendingoptions:'',
      })

      const [formData, updateFormData] = useState(initialFormData)

      const handleChange = e => {
        updateFormData({
          ...formData,
    
          // Trimming any whitespace
          [e.target.name]: e.target.value.trim(),
        })
      }

       const data = {
        firstname: formData.FirstName,
        lastname:formData.LastName,
        emailaddress:formData.emailAddress,
        mailedaddress: formData.mailedAddress,
       // attendingoptions: formData.attendingoptions,
        lunch:formData.lunch
       }

       function workshopMember(){

        typeof window !== 'undefined' ? sessionStorage.clear() : null
        if(isEmpty(formData.FirstName) === false && isEmpty(formData.LastName) === false && isEmpty(formData.emailAddress) === false && isEmpty(formData.mailedAddress) === false && isEmpty(formData.lunch)== false){
          if(validator.isEmail(formData.emailAddress)== true){
            
            sessionStorage.setItem('WorkShop',JSON.stringify(data))
            Swal.fire('Confirm').then(response => {
                /* Read more about isConfirmed, isDenied below */
                if (response.isConfirmed) {
                   sessionStorage.setItem('MembershipCategory', 'Workshop for member')
                  sessionStorage.setItem("createWorkshop", true);
                  sessionStorage.setItem("selectedPrice",15);
                  window.location.pathname="/paymentDetails";
                } 
              })
          }
          else{
            alert("Invalid email")
          }
          
        }
        else{
           alert("Check all fields are filled")
        }
         
       }

       function  workshopNonMember(){
        typeof window !== 'undefined' ? sessionStorage.clear() : null
        if(isEmpty(formData.FirstName) === false && isEmpty(formData.LastName) === false && isEmpty(formData.emailAddress) === false && isEmpty(formData.mailedAddress) === false && isEmpty(formData.lunch)== false){
          if(validator.isEmail(formData.emailAddress)== true){
            sessionStorage.setItem('WorkShop',JSON.stringify(data))
            Swal.fire('Confirm').then(response => {
                /* Read more about isConfirmed, isDenied below */
                if (response.isConfirmed) {
                  sessionStorage.setItem('MembershipCategory', 'Workshop for non-member')
                    sessionStorage.setItem("createWorkshop",true);
                    sessionStorage.setItem("selectedPrice",35);
                    window.location.pathname="/paymentDetails";
                } 
              })
          }
          else{
            alert("Invalid eamil")
          }
 
        }
        else{
           alert("Check all fields are filled")
        }
       }


    return(
        <div 
        className="card workshopcard"
        style={{
          backgroundColor:"#f9f9ff",
        }}>

        <div className="container pageContainer">
          <h2
            class="membershipTitle"
            style={{
              fontFamily: "Arial",
              fontSize: "28px",
              fontWeight: "600",
              textAlign:"center",
              color: "black",
            }}
          >
             Mini Workshop Registration Form
          </h2>
          <br/>
         
            <label htmlFor="firstname">
              {' '}
              <b>First name</b>
            </label>
            
            <input
              type="text"
              class="form-control"
              placeholder="Enter Your First name"
              name="FirstName"
              required
              onChange={handleChange}
              minlength="2"
              maxlength="20"
            />
            <br />
            <label htmlFor="lastname">
              {' '}
              <b>Last name</b>
            </label>
            
            <input
              type="text"
              class="form-control"
              placeholder="Enter Your Last name"
              name="LastName"
              required
              onChange={handleChange}
              minlength="2"
              maxlength="20"
            />
            <br />
            {/* ********* */}
            
            <label htmlFor="email">
            {' '}
            <b>Email Address</b>
            </label>
            <input
            type="email"
            class="form-control"
            placeholder="Enter your email address"
            name="emailAddress"
            required
            onChange={handleChange}
            minlength="2"
            maxlength="50"
            />
            <br/>
            {/* *********** */}
            <label htmlFor="email">
            {' '}
            <b>Mailing Address</b>
            </label>
            <input
            type="text"
            class="form-control"
            placeholder="Enter your mailing address"
            name="mailedAddress"
            required
            onChange={handleChange}
            minlength="2"
            maxlength="50"
            />
            <br/>

             {/* *********** */}
            <label htmlFor="lunch">
                {' '}
                <b>Lunch:</b>
              </label>
              <br />
              <select
                name="lunch"
                class="form-control"
                required
                onChange={handleChange}
              >
                <option hidden></option>
                <option value="Interested in ordering">Interested in ordering</option>
                <option value="Provide my own lunch">Provide my own lunch</option>
              </select>
              {/* ******** */}

        <div class="row">
        <div class="column">
        <div >
            <p  style={{marginBottom:"55px",fontSize:"18px"}}>Members</p>  
            <div style={{textAlign: "center"}}>
            <h5 style={{backgroundColor:"white", paddingTop:"7px",paddingBottom:"7px", border:"0.1px solid #D9D9D9",borderRadius:"5px",marginBottom:"25px"}}>$15 USD</h5>
            <button type="submit" id="" class="btn btn-success btn5" value="15" onClick={workshopMember}
            style={{backgroundColor:"rgb(0, 128, 0)",
            borderRadius:"7px",
            fontSize:"16px",
            }}>PAY NOW</button>
            </div>
        </div>
        </div>
        
        <div class="column">
        <div >
            <p  style={{marginBottom:"55px",fontSize:"18px"}}>Non Members</p>  
            <div style={{textAlign: "center"}}>
            <h5 style={{backgroundColor:"white", paddingTop:"7px",paddingBottom:"7px", border:"0.1px solid #D9D9D9",borderRadius:"5px",marginBottom:"25px"}}>$35 USD</h5>
            <button type="submit" id="" class="btn btn-success btn6" value="35" onClick={workshopNonMember}
            style={{backgroundColor:"rgb(0, 128, 0)",
            borderRadius:"7px",
            fontSize:"16px",
            }}>PAY NOW</button>
            </div>
        </div>
        </div>
    </div>

    <div>
      <a href="/joinrenew">To join or renew your ISRID Membership, Please CLICK HERE.</a>
    </div>


</div>
        </div>
    )
}

export default Workshop
