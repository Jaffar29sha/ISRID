// import React from "react";
// import {
//   MDBCarousel, MDBCarouselInner, MDBCarouselItem, MDBView, MDBContainer, MDBRow
//   , MDBCard, MDBCardBody, MDBCol, MDBCardImage, MDBCardText, MDBCardTitle, MDBBtn
// } from
//   "mdbreact";
// import { useStaticQuery, graphql } from 'gatsby';
// import Carousel from 'react-bootstrap/Carousel'
// import Image from 'gatsby-image'
// import { Link } from 'gatsby'

// const query = graphql`
//   {
//     allStrapiSponsors {
//       nodes {
//         Sponor_title
//         font_color {
//           color
//         }
//         font_family {
//           family
//         }
//         font_size {
//           size
//         }
//         font_weight {
//           weight
//         }
//         sponsor {
//           logo_height
//           logo_width
//           sponsor_URL
//           sponsor_title
//           logo {
//             childImageSharp {
//               fluid {
//                 ...GatsbyImageSharpFluid
//               }
//             }
//           }
//         }
//       }
//     }
//   }
// `

// const CarouselPage = () => {

//   const data = useStaticQuery(query)
//   const {
//     allStrapiSponsors: { nodes: splist },
//   } = data
//   debugger
//   const {
//     Sponor_title,
//     font_color,
//     font_family,
//     font_size,
//     font_weight,
//     sponsor,
//   } = splist[0]
//   //console.log(splist)
//   //console.log("Sponsers");
//   //console.log(sponsor);
//   const sponsorLength = sponsor.length;
//   //console.log("sponsor length is : " + sponsorLength);

//   let renderedData = sponsor.slice(0, 3).map((element) => {
//     return (
//       <MDBCol md="4">
//         <MDBCard className="mb-2">
//           {/* <MDBCardImage
//         className="img-fluid"
//         src={carouselInfo.logo.childImageSharp.fluid} /> */}
//           <Image
//             style={{
//               width: element.logo_width || '250px',
//               height: element.logo_height || '70px',
//             }}
//             fluid={element.logo.childImageSharp.fluid}
//             className="img-fluid sponsor-image"
//           />
//           <MDBCardBody>
//             <MDBBtn color="primary">MDBBtn</MDBBtn>
//           </MDBCardBody>
//         </MDBCard>
//       </MDBCol>
//     )
//   })

//   let renderedData1 = sponsor.slice(3, 6).map((element) => {
//     return (
//       <MDBCol md="4">
//         <MDBCard className="mb-2">
//           {/* <MDBCardImage
//         className="img-fluid"
//         src={carouselInfo.logo.childImageSharp.fluid} /> */}
//           <Image
//             style={{
//               width: element.logo_width || '250px',
//               height: element.logo_height || '70px',
//             }}
//             fluid={element.logo.childImageSharp.fluid}
//             className="img-fluid sponsor-image"
//           />
//           <MDBCardBody>
//             <MDBBtn color="primary">MDBBtn</MDBBtn>
//           </MDBCardBody>
//         </MDBCard>
//       </MDBCol>
//     )
//   })

//   //console.log(renderedData);

//   return (
//     <MDBContainer>
//       <MDBCarousel activeItem={1} slide={true} showControls={true} showIndicators={true} multiItem>
//         <MDBCarouselInner>
//           {/* <MDBRow> */}
//             {sponsor.map((element, index) => {
//               return (
//                 <MDBCarouselItem itemId={index}>
//                   <MDBView>
//                     <Image
//                       className="d-block w-100"
//                       src={element.logo.childImageSharp.fluid}
//                       alt="First slide"
//                     />
//                     {/* <Image
//                       // style={{
//                       //   width: element.logo_width || '250px',
//                       //   height: element.logo_height || '70px',
//                       // }}
//                       fluid={element.logo.childImageSharp.fluid}
//                       className="d-block w-100"
//                     /> */}
//                   </MDBView>
//                 </MDBCarouselItem>
//               )
//             })}

//           {/* </MDBRow> */}
//         </MDBCarouselInner>
//       </MDBCarousel>
//     </MDBContainer>
//   );
// }

// export default CarouselPage;
