import { combineReducers } from 'redux'

import loginFetchReducer from './login/loginFetchReducer'

const rootReducer = combineReducers({
    loginData: loginFetchReducer
})

export default rootReducer;