export default {
    USER_ID: `user_V2TjOGkvC6BcqaTAwfAjP`, //userID
    ContactForm_TEMPLATE_ID: `template_xy88y14`, //ContactFormEmail-templateID
    OTP_TEMPLATE_ID: `template_4niklzc`, //New-Password-OTP-templateID
    SERVICE_ID: `service_oum2d4o`
}