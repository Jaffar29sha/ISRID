
//Widgets types

export const BUTTON = "BUTTON";
export const LABEL = "LABEL";
export const EMAIL_INPUT = "EMAIL_INPUT";
export const INPUT = "INPUT";
export const TITLELABLE = "TITLELABLE";

export const PASSWORD_INPUT = 'PASSWORD_INPUT';
export const CHECKBOX = 'CHECKBOX';

export const CAPTCHA = 'CAPTCHA';

export const AXIOSLINK = 'https://cp.iowastaterid.org/'

export const BASEURL = 'http://iowastaterid.org'
export const IMAGELINK = 'https://cp.iowastaterid.org'
