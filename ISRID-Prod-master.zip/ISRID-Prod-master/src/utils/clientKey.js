export default {
    CLIENT_ID : `AeccRGe5asghR_Yp_0QzhodWYv6iCZiB5gGd-vtcyDMbhSleo2J9j5P82lpCb6yGsxNStxXJl6ILj_nB`
}
