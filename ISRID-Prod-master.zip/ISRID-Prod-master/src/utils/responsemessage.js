import React from 'react'

export const errorMessage = (error) => {
    const responseData = error.response.data;

    if (responseData.message.length > 1 && responseData.message[0].messages.length > 1) {

        return responseData.message[0].messages[0].message;
    }
    else {
        return 'Unknow error...'
    }


}

export const erroCode = (error) => {

}

