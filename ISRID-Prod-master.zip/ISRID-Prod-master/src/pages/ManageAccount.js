import React, {useState, useEffect} from 'react'
import ManagePro from "../components/ManageProfile/managepro";
import Layout from '../components/layout'
import Login from '../pages/login';


const ManageAccount = ({ location }) =>{
    const [agreed, setAgreed] = useState(false)

    // This runs when the page is loaded.
    useEffect(() => {
      if (localStorage.getItem('isAuthenticated')) {
        setAgreed(true)
      }
    }, [])
  
    return(
 
        <Layout location={location}>
             {!agreed ? (
               <>
               <Login loginModal={agreed} />
               <p className="oMember">Only members can view this page</p>
               </>
              ) : (
               <div className="box ">
                  <ManagePro />
               </div>
             )}
           </Layout>
       )
}

export default ManageAccount 