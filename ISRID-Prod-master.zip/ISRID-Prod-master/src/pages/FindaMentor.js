import React, {useState, useEffect} from 'react'
import Layout from '../components/layout'
import Login from '../pages/login';
import '../assets/main.css';
import { Link } from 'gatsby'


const FindaMentor = ({ location }) => {
  

  const [agreed, setAgreed] = useState(false)

  // This runs when the page is loaded.
  useEffect(() => {
    if (localStorage.getItem('isAuthenticated')) {
      setAgreed(true)
    }
  }, [])
  return (
    <Layout location={location} crumbLabel="Newsletter">
      {!agreed ? (
        <>
        <Login loginModal={agreed} />
        <p className="oMember">Only members can view this page</p>
        </>
      ) : (
        <div className="box ">
           
        </div>
      )}
    </Layout>
  )
}

export default FindaMentor
