import React from "react"
import Volunteer from "../components/Volunteer/Volunteer"

const VolunteerPage =() =>{
    return(
        <Volunteer />
    )
}

export default VolunteerPage