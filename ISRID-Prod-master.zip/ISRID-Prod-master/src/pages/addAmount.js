import { isEmpty } from "lodash";
import { Container } from "mdbreact";
import '../assets/workshop.css'
import React from "react";
import Swal from "sweetalert2"
import Layout from '../components/layout'

const AddAmount = () =>{
    const initialFormData = Object.freeze({
        payingAmount: '',
    })

    const [formData, updateFormData] = React.useState(initialFormData)
    const handleChange = e => {
      updateFormData({
        ...formData,
  
        // Trimming any whitespace
        [e.target.name]: e.target.value.trim(),
      })
    }

    function pay(){
        if(isEmpty(formData.payingAmount)== false && formData.payingAmount >= 1){
            sessionStorage.setItem("selectedPrice",formData.payingAmount);
            sessionStorage.setItem('AddAmount', 'Swag Order')
            window.location.pathname = '/paymentDetails/'
        }
    }

return(
    <Layout>
        <div
          className="card workshopcard"
          style={{ backgroundColor: "#f9f9ff"}}>
        
        <div className="container">
          <h2
            class="membershipTitle"
            style={{
              fontFamily: "Arial",
              fontSize: "28px",
              fontWeight: "600",
              textAlign:"center",
              color: "black",
            }}
          >
             Swag Order
          </h2>
          <br/>
        <label htmlFor="">
            {' '}
            <b>Enter Payment Amount:</b>
        
        </label>
        &nbsp;
        <input
            type="number"
            class="form-control"
            placeholder="Enter Payment Amount"
            name="payingAmount"
            required
            onChange={handleChange}
            minlength="1"
        />
        <br />
        <button type="submit" class="btn btn-success " onClick={pay}
            style={{backgroundColor:"rgb(0, 128, 0)",
            borderRadius:"7px",
            fontSize:"16px",
            }}>Pay Now</button>
        </div>
        </div>
    </Layout>
)
}

export default AddAmount
