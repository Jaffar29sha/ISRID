import { isEmpty } from "lodash"
import React, { useState } from "react"
import '../assets/workshop.css'
import Layout from '../components/layout'
import Swal from 'sweetalert2'
var validator = require('validator');
import '../components/membershipApplication/membershipapplication.css'
import emailjs from "emailjs-com";

const Conference = () =>{

    const initialFormData = Object.freeze({
        FirstName: '',
        LastName: '',
        emailAddress: '',  
        PreferredPhoneNumber:'',
        dietary:'',
        banquet:'',
      })

      const [formData, updateFormData] = useState(initialFormData)

      const handleChange = e => {
        updateFormData({
          ...formData,
    
          // Trimming any whitespace
          [e.target.name]: e.target.value.trim(),
        })
      }
       const data = {
        firstname: formData.FirstName,
        lastname:formData.LastName,
        emailaddress:formData.emailAddress,
        phonenumber: formData.PreferredPhoneNumber,
        dietary:formData.dietary,
        banquet:formData.banquet === '' ? 0 : formData.banquet
       }

       function conferenceMember(){
        

        typeof window !== 'undefined' ? sessionStorage.clear() : null
        if(isEmpty(formData.FirstName) === false && isEmpty(formData.LastName) === false && isEmpty(formData.emailAddress) === false && isEmpty(formData.PreferredPhoneNumber) === false ){
          if(validator.isEmail(formData.emailAddress)== true){
            
            sessionStorage.setItem('conference',JSON.stringify(data))
            Swal.fire({
              title: 'Confirm',
              text: `Member = 175 + Banquet = ${formData.banquet === '' ? 0 : formData.banquet * 50}`,
            }).then(response => {
                /* Read more about isConfirmed, isDenied below */
                if (response.isConfirmed) {
                    sessionStorage.setItem('MembershipCategory', 'Conference Registration for member')
                  sessionStorage.setItem("selectedPrice", 175 + (formData.banquet === '' ? 0 : formData.banquet * 50));
                  sessionStorage.setItem("Setconference",true);
                  window.location.pathname="/paymentDetails";
                } 
              })
          }
          else{
            alert("Invalid email")
          }
          
        }
        else{
           alert("Check all fields are filled")
        }
         
       }

       function conferenceNonMember(){

        typeof window !== 'undefined' ? sessionStorage.clear() : null
        if(isEmpty(formData.FirstName) === false && isEmpty(formData.LastName) === false && isEmpty(formData.emailAddress) === false && isEmpty(formData.PreferredPhoneNumber) === false ){
          if(validator.isEmail(formData.emailAddress)== true){
            
            sessionStorage.setItem('conference',JSON.stringify(data))
            Swal.fire({
              title: 'Confirm',
              text: `Non-Member = 200 + Banquet = ${formData.banquet === '' ? 0 : formData.banquet * 50}`,
            }).then(response => {
                /* Read more about isConfirmed, isDenied below */
                if (response.isConfirmed) {
                    sessionStorage.setItem('MembershipCategory', 'Conference Registration for non-member')
                  sessionStorage.setItem("selectedPrice",200+(formData.banquet === '' ? 0 : formData.banquet * 50));
                  sessionStorage.setItem("Setconference",true);
                  window.location.pathname="/paymentDetails";
                } 
              })
          }
          else{
            alert("Invalid email")
          }
          
        }
        else{
           alert("Check all fields are filled")
        }
         
       }

       function conferenceStudent(){

       
        typeof window !== 'undefined' ? sessionStorage.clear() : null
        if(isEmpty(formData.FirstName) === false && isEmpty(formData.LastName) === false && isEmpty(formData.emailAddress) === false && isEmpty(formData.PreferredPhoneNumber) === false){
          if(validator.isEmail(formData.emailAddress)== true){
            
            sessionStorage.setItem('conference',JSON.stringify(data))
            Swal.fire({
              title: 'Confirm',
              text: `Student = 125 + Banquet = ${formData.banquet === '' ? 0 : formData.banquet * 50}`,
            }).then(response => {
                /* Read more about isConfirmed, isDenied below */
                if (response.isConfirmed) {
                  sessionStorage.setItem('MembershipCategory', 'Conference Registration for student')
                  sessionStorage.setItem("selectedPrice",125+(formData.banquet === '' ? 0 : formData.banquet * 50));
                  sessionStorage.setItem("Setconference",true);
                  window.location.pathname="/paymentDetails";
                } 
              })
          }
          else{
            alert("Invalid email")
          }
          
        }
        else{
           alert("Check all fields are filled")
        }
         
       }

       function conferencePayByCheque(){
      

        typeof window !== 'undefined' ? sessionStorage.clear() : null
        if(isEmpty(formData.FirstName) === false && isEmpty(formData.LastName) === false && isEmpty(formData.emailAddress) === false && isEmpty(formData.PreferredPhoneNumber) === false){
          if(validator.isEmail(formData.emailAddress)== true){
            data.payment = "Cheque"
      
                  Swal.fire({
                    title:'Thank you for registering.',
                    html: 'Send by mail to ,2555 315th Street Blairsburg, IA 50034. Questions Email: <a href="mailto:tiffany.cramer@outlook.com">tiffany.cramer@outlook.com</a>',
                    confirmButtonColor: '#00c851',
                  }).then(result1 => {
                    emailjs.send('service_giuqtyt', 'template_gibe9pj', data, 'VRxPH2--CDfuGuJV3')
                      .then(
                        function(result) {
                          if (result1.isConfirmed) {
                            window.location.pathname = '/home'
                          }
                          //console.log('SUCCESS!', result.status, result.text);
                        },
                        function(error) {
                          //console.log('FAILED...', error);
                        }
                      )
                  })
                } 
          else{
            alert("Invalid email")
          }
          
        }
        else{
           alert("Check all fields are filled")
        }
       }

       function conferenceBanquet(){

        typeof window !== 'undefined' ? sessionStorage.clear() : null
        if(isEmpty(formData.FirstName) === false && isEmpty(formData.LastName) === false && isEmpty(formData.emailAddress) === false && isEmpty(formData.PreferredPhoneNumber) === false){
          if(validator.isEmail(formData.emailAddress)== true){
            
            sessionStorage.setItem('conference',JSON.stringify(data))
            Swal.fire({
              title: 'Confirm',
              text: `Banquet = $ ${formData.banquet === '' ? 50 : formData.banquet * 50}`,
            }).then(response => {
                /* Read more about isConfirmed, isDenied below */
                if (response.isConfirmed) {
                  sessionStorage.setItem('MembershipCategory', 'Banquet only')
                  sessionStorage.setItem("selectedPrice",(formData.banquet === '' ? 50 : formData.banquet * 50));
                  sessionStorage.setItem("Setconference",true);
                  window.location.pathname="/paymentDetails";
                } 
              })
          }
          else{
            alert("Invalid email")
          }
          
        }
        else{
           alert("Check all fields are filled")
        }
       }


    return(
        <Layout>
        <div 
        className="card workshopcard"
        style={{
          backgroundColor:"#f9f9ff",
        }}>

        <div className="container pageContainer">
          <h2
            class="membershipTitle"
            style={{
              fontFamily: "Arial",
              fontSize: "28px",
              fontWeight: "600",
              textAlign:"center",
              color: "black",
            }}
          >
             Conference Registration Form
          </h2>
          <br/>
         
            <label htmlFor="firstname">
              {' '}
              <b>First name</b>
            </label>
            
            <input
              type="text"
              class="form-control"
              placeholder="Enter Your First name"
              name="FirstName"
              required
              onChange={handleChange}
              minlength="2"
              maxlength="20"
            />
            <br />
            <label htmlFor="lastname">
              {' '}
              <b>Last name</b>
            </label>
            
            <input
              type="text"
              class="form-control"
              placeholder="Enter Your Last name"
              name="LastName"
              required
              onChange={handleChange}
              minlength="2"
              maxlength="20"
            />
            <br />
            {/* ********* */}
            
            <label htmlFor="email">
            {' '}
            <b>Email Address</b>
            </label>
            <input
            type="email"
            class="form-control"
            placeholder="Enter your email address"
            name="emailAddress"
            required
            onChange={handleChange}
            minlength="2"
            maxlength="50"
            />
            <br/>
            {/* *********** */}
            <label htmlFor="phone">
            {' '}
            <b>Phone number</b>
            </label>
            <input
                type="text"
                class="form-control"
                inputmode="numeric"
                placeholder="Enter your Phone number"
                name="PreferredPhoneNumber"
                required
                onChange={handleChange}
                minlength="10"
                maxlength="12"
              />
            <br/>
            {/* *********** */}
            <label htmlFor="lastname">
              {' '}
              <b>Request dietary accommodations</b>
            </label>
            
            <input
              type="text"
              class="form-control"
              placeholder="Request dietary accommodations"
              name="dietary"
              onChange={handleChange}
            />
            <br />
            {/* ********* */}

            <div>
              <label htmlFor="opt" style={{paddingRight:"20px"}}>
                <b>Additional banquet guest tickets available for $50.00</b>
              </label>
              <select class="form-control" onChange={handleChange} name="banquet" style={{width:"15%"}}>
                <option value="0">0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                
              </select>
            </div>
<br/>

        <div class="row">
        <div class="column">
                <div  >
                    <h3  style={{marginBottom:"35px",fontSize:"20px",textAlign: "center"}}>Pay by Check</h3>  
                    <div style={{textAlign: "center"}}>
                    <button type="submit" id="" class="btn btn-success btn5" value="125" onClick={conferencePayByCheque}
                    style={{backgroundColor:"rgb(0, 128, 0)",
                    borderRadius:"7px",
                    fontSize:"14px",
                    }}>Pay by Check</button>
                    </div>
                </div>
                </div>
                <div class="column">
                <div  >
                    <h3  style={{marginBottom:"35px",fontSize:"20px",textAlign: "center"}}>Banquet Only</h3>  
                    <div style={{textAlign: "center"}}>
                    <button type="submit" id="" class="btn btn-success btn6" value="50" onClick={conferenceBanquet}
                    style={{backgroundColor:"rgb(0, 128, 0)",
                    borderRadius:"7px",
                    fontSize:"14px",
                    }}>Pay for banquet</button>
                    </div>
                </div>
                </div>
        </div>
            <br/>
        <div class="row">
        <div class="column">
        <div >
            <h3  style={{marginBottom:"35px",fontSize:"20px",textAlign: "center"}}>Members</h3>  
            <div style={{textAlign: "center"}}>
            <h5 style={{backgroundColor:"white", paddingTop:"7px",paddingBottom:"7px", border:"0.1px solid #D9D9D9",borderRadius:"5px",marginBottom:"25px"}}>$175 USD</h5>
            <button type="submit" id="" class="btn btn-success btn5" value="175" onClick={conferenceMember}
            style={{backgroundColor:"rgb(0, 128, 0)",
            borderRadius:"7px",
            fontSize:"16px",
            }}>PAY NOW</button>
            </div>
        </div>
        </div>
        
        <div class="column">
        <div >
            <h3  style={{marginBottom:"35px",fontSize:"20px",textAlign: "center"}}>Non Members</h3>  
            <div style={{textAlign: "center"}}>
            <h5 style={{backgroundColor:"white", paddingTop:"7px",paddingBottom:"7px", border:"0.1px solid #D9D9D9",borderRadius:"5px",marginBottom:"25px"}}>$200 USD</h5>
            <button type="submit" id="" class="btn btn-success btn6" value="200" onClick={conferenceNonMember}
            style={{backgroundColor:"rgb(0, 128, 0)",
            borderRadius:"7px",
            fontSize:"16px",
            }}>PAY NOW</button>
            </div>
        </div>
        </div>
    </div>
    <br/>
    <div style={{justifyContent:"center",display:"flex"}}>
        <div  >
            <h3  style={{marginBottom:"35px",fontSize:"20px",textAlign: "center"}}>Student</h3>  
            <div style={{textAlign: "center"}}>
            <h5 style={{backgroundColor:"white", paddingTop:"7px",paddingBottom:"7px", border:"0.1px solid #D9D9D9",borderRadius:"5px",marginBottom:"25px"}}>$125 USD</h5>
            <button type="submit" id="" class="btn btn-success btn6" value="125" onClick={conferenceStudent}
            style={{backgroundColor:"rgb(0, 128, 0)",
            borderRadius:"7px",
            fontSize:"16px",
            }}>PAY NOW</button>
            </div>
        </div>
    </div>
<br/>
   
</div>
        </div>
        </Layout>
    )
}

export default Conference
