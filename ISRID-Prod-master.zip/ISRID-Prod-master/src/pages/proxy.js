import React from "react";
import Layout from '../components/layout'
import '../assets/workshop.css'
import { AXIOSLINK } from "../utils/constants";
import PROXY from '../images/Proxy-Voting-Form.png'

const proxy = ( ) =>{
    return (
        <Layout>
            <div 
        className="card workshopcard"
        style={{
          backgroundColor:"#f9f9ff",
        }}>

        <div className="container pageContainer">
          <h2
            class="membershipTitle"
            style={{
              fontFamily: "Arial",
              fontSize: "28px",
              fontWeight: "600",
              textAlign:"center",
              color: "black",
            }}
          >
             ISRID Voting Proxy Form
          </h2>
          <br/>
          </div>
          <a href={AXIOSLINK + 'uploads/ISRID_Voting_Proxy_Form_Membership_Meeting_78495b7625.pdf'}>Click HERE to view the proxy voting form</a>
          <br/>
          <img src={PROXY}  />
        
          </div>
        </Layout>
    )
}

export default proxy
