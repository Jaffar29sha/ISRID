import React from "react"
import Nominate from "../components/Nominate/Nominate"

const NominatePage =() =>{
    return (
        <Nominate />
    )
}

export default NominatePage