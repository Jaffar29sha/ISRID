import React, {useState, useEffect} from 'react'
import Memoriam from '../components/memoriam/memoriam'
import Layout from '../components/layout'
import Login from '../pages/login';



const MemoriamPage = ({ location }) => 
{
  const [agreed, setAgreed] = useState(false)

  // This runs when the page is loaded.
  useEffect(() => {
    if (localStorage.getItem('isAuthenticated')) {
      setAgreed(true)
    }
  }, [])


return(
 
 <Layout location={location}>
      {!agreed ? (
        <>
        <Login loginModal={agreed} />
        <p className="oMember">Only members can view this page</p>
        </>
       ) : (
        <div className="box ">
          <Memoriam />
        </div>
      )}
    </Layout>
)
}
export default MemoriamPage