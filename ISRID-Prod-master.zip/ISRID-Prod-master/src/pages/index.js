import * as React from 'react'
import Layout from '../components/layout'
import SEO from '../components/seo'
import Events from '../components/Events'
//import {BrowserRouter as Router} from 'react-router-dom'
import { graphql } from 'gatsby'
let Component = React.Component;



export default function Main({ data, location }) {
  const {
    allStrapiEvents: { nodes: events },
  } = data

  return (
   // <Router>
    <Layout location={location} crumbLabel="Home">
      <SEO title="ISRID" />
      <main >
        <Events events={events} showLink />
      </main>{' '}
    </Layout>
    //</Router>
  )
}
export const query = graphql`
  {
    allStrapiEvents(sort: { fields: order, order: ASC }, limit: 100) {
      nodes {
        title
        order
        id
        description {
          description
          id
        }
        slug
        font_family {
          id
          family
        }
        font_color {
          color
          id
        }
        bg_color {
          color
        }
        font_size {
          size
        }
        font_weight {
          weight
        }
        updated_at
        created_at(formatString: "MM Do, YYYY")
        image {
          childImageSharp {
            fluid {
              ...GatsbyImageSharpFluid
            }
          }
        }
        image_details {
          src
          width
          height
          margin
        }
        event_classname
      }
    }
  }
`
