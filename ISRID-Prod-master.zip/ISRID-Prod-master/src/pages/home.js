import React from 'react'
import Layout from '../components/layout'
import { graphql } from 'gatsby'
import Events from '../components/Events'
import SEO from '../components/seo'

const Board = ({
  data: {
    allStrapiEvents: { nodes: events },
  }, location
}) => {
  return (
    <Layout location={location} crumbLabel="Home" >
      <SEO title="Events" />
      <section className="blog-page">
        <Events events={events} showLink key={'event'}/>
      </section>
    </Layout>
  )
}

export const query = graphql`
  {
    allStrapiEvents(sort: { order: ASC, fields: order }) {
      nodes {
        title
        title_align
        id
        description {
          description
          id
        }
        slug
        updated_at
        font_family {
          id
          family
        }
        font_color {
          color
          id
        }
        bg_color {
          color
        }
        font_size {
          size
        }
        font_weight {
          weight
        }
        created_at(formatString: "MM Do, YYYY")
        event_classname
        image_details {
          src
          width
          height
          margin
        }
        image {
          childImageSharp {
            fluid {
              ...GatsbyImageSharpFluid
            }
          }
        }
      }
    }
  }
`
export default Board
