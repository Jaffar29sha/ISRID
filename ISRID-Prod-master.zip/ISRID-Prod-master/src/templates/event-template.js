import React from 'react'
import { graphql, Link, navigate } from 'gatsby'
import Layout from '../components/layout'
import SEO from '../components/seo'
import StepperComp from '../components/Stepper/StepperComp'
import '../assets/main.css'
import '../assets/eventTemplate.css'
import MDEditor from '@uiw/react-md-editor';


const ComponentName = ({ data }) => {
  const componentData = { ...data.blog }

  const pageId =
    typeof window !== 'undefined'
      ? new URLSearchParams(window.location.search).get('id')
      : -1

  const selectedDesc = componentData.description.filter(item => {
    return item.id == pageId
  })

  if (selectedDesc.length == 0 && pageId < 0) {
    //alert('Content Not available')
    //navigate(-1)
  }

  return (
    <Layout>
      <SEO title={componentData.slug} />

      <div className="box">
        <div className="container">
          <div className="row team-player">
            {selectedDesc.map((desc, index) => {
              return (
                <>
                  {desc.full_content &&
                    desc.full_content.map((content, index2) => {
                      debugger
                      return (
                        <div
                          className={
                            content.className ? content.className : 'col-md-12'
                          }
                        >
                          <li
                            style={{
                              listStyle: componentData.content_align,
                              'list-style-type': 'none',
                            }}
                            key={desc.id}
                          >
                            <h3>{content.title}</h3>

                            <div className="square">
                              {content.image && (
                                <div>
                                  {/* <Link
                                    to={
                                      content.image.link_url
                                        ? content.image.link_url
                                        : ''
                                    }
                                    target="_blank"
                                  > */
                                  }
                                    <img
                                      {...content.image}
                                      style={{ ...content.image }}
                                    />
                                  {/* </Link> */}
                                </div>
                              )}
                              <div>
                                {content.step_details &&
                                  content.step_details.map(
                                    (stepContent, key) => {
                                      debugger
                                      return (
                                        <div>
                                          <StepperComp stepData={stepContent} />
                                        </div>
                                      )
                                    }
                                  )}
                              </div>

                              <p style={{ textAlign: 'justify' }}>
                              <MDEditor.Markdown source={content.Description_MD}/>
                               {/* <MainDescription desc={content.description} /> */}
                              </p>
                            </div>
                          </li>
                        </div>
                      )
                    })}
                </>
              )
            })}
          </div>
        </div>
      </div>
    </Layout>
  )
}

export function MainDescription({ desc }) {
  return <div dangerouslySetInnerHTML={{ __html: desc }}></div>
}

export const query = graphql`
  query GetSingleEvents($slug: String) {
    blog: strapiEvents(slug: { eq: $slug }) {
      title
      id
      content_align
      description {
        description
        id
        full_content {
          Description_MD
          content_order_id
          description
          title
          image_url
          image {
            height
            src
            width
            float
            margin
            link_url
            border
          }
          step_details {
            data {
              content
              title
            }
            step
          }
          className
        }
        bulletin_id
      }
      font_family {
        id
        family
      }
      font_color {
        color
        id
      }
      slug
      updated_at
      title_align
      created_at(formatString: "MM Do, YYYY")
      event_classname
      image_details {
        src
        width
        height
        margin
      }
    }
  }
`

export default ComponentName
