# # React Bootstrap with Material Design

[![npm version](https://badge.fury.io/js/mdbreact.svg)](https://badge.fury.io/js/mdbreact)

A simple starter which lets you quickly start developing with Gastby and Material Design For Bootstrap

![thumb](https://mdbootstrap.com/img/React/gatsby-mdbreact-starter.png)

## Features

- [React Bootstrap with Material Design](https://mdbootstrap.com/react/) css framework.
- Free for personal and commercial use
- Fully responsive

## Installation
Install this starter (assuming Gatsby is installed) by running from your CLI:
`gatsby new projectName https://github.com/anna-morawska/gatsby-starter-material-design-for-bootstrap`

## Usage

develop
`gatsby develop`


## Utilsused 


## Carousal 
https://www.npmjs.com/package/react-multi-carousel : For Reference

## Swal
https://sweetalert.js.org/guides/

## MDB Component

https://mdbootstrap.com/docs/react/

