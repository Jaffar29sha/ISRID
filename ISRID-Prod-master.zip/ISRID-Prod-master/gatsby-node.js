const path = require('path')

// create pages dynamically
exports.createPages = async ({ graphql, actions }) => {
  const { createPage } = actions
  const result = await graphql(`
    {
      members: allStrapiMembers {
        nodes {
          slug
        }
      }
    }
  `)
  result.data.members.nodes.forEach(members => {
    createPage({
      path: `/board/${members.slug}`,
      component: path.resolve(`src/templates/board-members-template.js`),
      context: {
        slug: members.slug,
      },
    })
  })

  const resultData = await graphql(`
    {
      events: allStrapiEvents {
        nodes {
          slug
          description {
            id
          }
        }
      }
    }
  `)
  resultData.data.events.nodes.forEach(event => {
    createPage({
      path: `/board/${event.slug}`,
      component: path.resolve(`src/templates/event-template.js`),
      context: {
        slug: event.slug,
      },
    })
  })

  const resultData1 = await graphql(`
    {
      allStrapiMemoriamCollecionTypes {
        edges {
          node {
            Slug
          }
        }
      }
    }
  `)
    resultData1.data.allStrapiMemoriamCollecionTypes.edges.forEach(({ node }) => {
      createPage({
        path: `/memoriam/${node.Slug}`,
        component: path.resolve(`src/templates/memoriam-template.js`),
        context: {
          Slug: node.Slug,
        },
      })
    })
  
  
}

exports.sourceNodes = ({ actions }) => {
  const { createTypes } = actions
  const typeDefs = `
    type StrapiConfRegistrationForms implements Node {
      Test_type: String
      image_test: String
      Data: [Data_info]
    }

   type Data_info {
      Field_order  :String
      Title :String
      Type_id :String
      Value :String
      image_url :String
      image_details: image_details_info 
      field_type: field_type_info
      Field_attributes :Field_attributes_info 
    }

    type field_type_info    {
      Field_Kind  :String
    }

    type image_details_info {
      src :String
      width :String
      height :String
      marginTop :String
      margin :String

    }

    type Field_attributes_info {
      label :String
      minlength :String
      name :String
      required :String
      type :String
      value :String
      className :String
      color :String
      float :String
    }
  `
  const typeDefs2 = `
  type StrapiEvents implements Node {
      content_align: String
      order: String
      strapiId: String
      slug: String
      title: String
      title_align: String
      image_details: image_details_info 
      image: File
      description: [description_info]
  }

  type description_info {
    description : String
    id : String
    full_content: [full_content_info] 
    bulletin_id: String
  }

  type  full_content_info {
    content_order_id : String
    description: String
    title: String
    image_url: String
    image: image_info
    step_details: [step_content_info]
    className: String
  }

  type image_info {
    height: String
    src: String
    width: String
    float: String
    margin: String
    link_url: String
  }

  type step_content_info {
    data: [data_info] 
    step: String
  }

  type data_info {
    content: String
    title: String
  }
  
`


  const typeDefSubNavBar = `
  type StrapiSubnavbars implements Node{
    bg_mega_menu: bg_mega_menu_info
    bg_sub_navbar: bg_sub_navbar_info
    menu_hover_color: menu_hover_color_info
    menu_item: [menu_item_info] 
  }

  type bg_mega_menu_info {
    color: String
  }

  type bg_sub_navbar_info{
    color: String
  }
  type menu_hover_color_info{
    color: String
  }

  type  menu_item_info {
    order: String
    menu_url: String
    menu_name: String 
    submenu_name: [submenu_name_info]
  }
  type submenu_name_info {
    font_color: font_color_info
    font_family: font_family_info
    font_size: font_size_info
    font_weight: font_weight_info
    url: String
    menu_name: String
  }

  type font_color_info {
    color: String
  }
  type font_family_info {
    family: String
  }
  type font_size_info {
    size: String
  }
  type font_weight_info {
    weight: String
  }
  
`

  createTypes([typeDefs, typeDefs2, typeDefSubNavBar])
}
