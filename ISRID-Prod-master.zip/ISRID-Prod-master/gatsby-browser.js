import '@fortawesome/fontawesome-free/css/all.min.css'
import 'bootstrap-css-only/css/bootstrap.min.css'
import 'mdbreact/dist/css/mdb.css'
import './src/assets/main.css'
import wrapWithProvider from "./wrap-with-provider"
import 'gatsby-plugin-breadcrumb/gatsby-plugin-breadcrumb.css'

export const wrapRootElement = wrapWithProvider
export const onServiceWorkerUpdateReady = () => window.location.reload();
